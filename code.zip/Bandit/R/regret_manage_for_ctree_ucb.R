regret_manage_for_ctree_ucb <- function(ctree_res){
  
  #return list of choice
  
  
}