# run this if it's your first time using it to install


if (!require("ggplot2")) install.packages("ggplot2",repos="http://cran.r-project.org")
if (!require("partykit")) install.packages("partykit",repos="http://cran.r-project.org")
if (!require("tictoc")) install.packages("tictoc",repos="http://cran.r-project.org")
if (!require("listdtr")) install.packages("listdtr",repos="http://cran.r-project.org")